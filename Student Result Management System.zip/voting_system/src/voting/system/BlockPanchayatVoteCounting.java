package voting.system;

public class BlockPanchayatVoteCounting {
		private int count;

		public BlockPanchayatVoteCounting(int count) {
			super();
			this.count = count;
		}

		public BlockPanchayatVoteCounting() {
			super();
			// TODO Auto-generated constructor stub
		}

		public int getCount() {
			return count;
		}

		public void setCount(int count) {
			this.count = count;
		}
		
}
