package voting.system;

public class Type {
	private String type_value;

	public Type(String type_value) {
		super();
		this.type_value = type_value;
	}

	public Type() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getType_value() {
		return type_value;
	}

	public void setType_value(String type_value) {
		this.type_value = type_value;
	}
	
}
