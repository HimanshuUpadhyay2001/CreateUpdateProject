package voting.system;

public class CountVote {
	private int count_vote;

	public CountVote(int count_vote) {
		super();
		this.count_vote = count_vote;
	}

	public CountVote() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getCount_vote() {
		return count_vote;
	}

	public void setCount_vote(int count_vote) {
		this.count_vote = count_vote;
	}
	
}
