package voting.system;

public class ZilaPanchayatCount {
	private int count;

	public ZilaPanchayatCount(int count) {
		super();
		this.count = count;
	}

	public ZilaPanchayatCount() {
		super();
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
}
