package voting.system;

import java.sql.Timestamp;

public class AdminCount {
	private int admincount;
	private int super_admin_id;
	private String name;
	private Long adhar;
	private String user_name;
	private String password;
	private String age;
	private String profile;
	private String type;
	private String gender;
	private Timestamp date_time;
	public AdminCount(int admincount, int super_admin_id, String name, Long adhar, String user_name, String password,
			String age, String profile, String type, String gender, Timestamp date_time) {
		super();
		this.admincount = admincount;
		this.super_admin_id = super_admin_id;
		this.name = name;
		this.adhar = adhar;
		this.user_name = user_name;
		this.password = password;
		this.age = age;
		this.profile = profile;
		this.type = type;
		this.gender = gender;
		this.date_time = date_time;
	}
	public AdminCount(String name, Long adhar, String user_name, String password, String age, String profile,
			String type, String gender) {
		super();
		this.name = name;
		this.adhar = adhar;
		this.user_name = user_name;
		this.password = password;
		this.age = age;
		this.profile = profile;
		this.type = type;
		this.gender = gender;
	}
	public AdminCount(int admincount) {
		super();
		this.admincount = admincount;
	}
	public AdminCount() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getAdmincount() {
		return admincount;
	}
	public void setAdmincount(int admincount) {
		this.admincount = admincount;
	}
	public int getSuper_admin_id() {
		return super_admin_id;
	}
	public void setSuper_admin_id(int super_admin_id) {
		this.super_admin_id = super_admin_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getAdhar() {
		return adhar;
	}
	public void setAdhar(Long adhar) {
		this.adhar = adhar;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getProfile() {
		return profile;
	}
	public void setProfile(String profile) {
		this.profile = profile;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Timestamp getDate_time() {
		return date_time;
	}
	public void setDate_time(Timestamp date_time) {
		this.date_time = date_time;
	}
	
}
