package voting.system;

public class StateCountVote {
		private int state;

		public StateCountVote() {
			super();
			// TODO Auto-generated constructor stub
		}

		public StateCountVote(int state) {
			super();
			this.state = state;
		}

		public int getState() {
			return state;
		}

		public void setState(int state) {
			this.state = state;
		}

		

		
}
