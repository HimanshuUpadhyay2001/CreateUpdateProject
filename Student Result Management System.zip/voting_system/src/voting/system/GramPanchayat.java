package voting.system;

import java.sql.Timestamp;

public class GramPanchayat {
	private int gram_id;
	private String symbol_name;
	private String symbol_pick;
	private String name;
	private Timestamp date_time;
	public GramPanchayat(int gram_id, String symbol_name, String symbol_pick, String name, Timestamp date_time) {
		super();
		this.gram_id = gram_id;
		this.symbol_name = symbol_name;
		this.symbol_pick = symbol_pick;
		this.name = name;
		this.date_time = date_time;
	}
	public GramPanchayat(String symbol_name, String symbol_pick, String name) {
		super();
		this.symbol_name = symbol_name;
		this.symbol_pick = symbol_pick;
		this.name = name;
	}
	public GramPanchayat() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getGram_id() {
		return gram_id;
	}
	public void setGram_id(int gram_id) {
		this.gram_id = gram_id;
	}
	public String getSymbol_name() {
		return symbol_name;
	}
	public void setSymbol_name(String symbol_name) {
		this.symbol_name = symbol_name;
	}
	public String getSymbol_pick() {
		return symbol_pick;
	}
	public void setSymbol_pick(String symbol_pick) {
		this.symbol_pick = symbol_pick;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Timestamp getDate_time() {
		return date_time;
	}
	public void setDate_time(Timestamp date_time) {
		this.date_time = date_time;
	}
	
}
