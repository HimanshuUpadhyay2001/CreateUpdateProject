package voting.system;

import java.sql.Timestamp;

public class AdminReplyMessage {
	private int reply_id;
	private String reply_message;
	private String user_name;
	private String name;
	private Timestamp date_time;
	public AdminReplyMessage(int reply_id, String reply_message, String user_name, String name, Timestamp date_time) {
		super();
		this.reply_id = reply_id;
		this.reply_message = reply_message;
		this.user_name = user_name;
		this.name = name;
		this.date_time = date_time;
	}
	public AdminReplyMessage(String reply_message, String user_name, String name) {
		super();
		this.reply_message = reply_message;
		this.user_name = user_name;
		this.name = name;
	}
	public AdminReplyMessage() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getReply_id() {
		return reply_id;
	}
	public void setReply_id(int reply_id) {
		this.reply_id = reply_id;
	}
	public String getReply_message() {
		return reply_message;
	}
	public void setReply_message(String reply_message) {
		this.reply_message = reply_message;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Timestamp getDate_time() {
		return date_time;
	}
	public void setDate_time(Timestamp date_time) {
		this.date_time = date_time;
	}
	
}
