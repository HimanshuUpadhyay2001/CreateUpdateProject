package voting.system;

import java.sql.Timestamp;

public class ZilaPanchayat {
	private int zila_id;
	private String symbol_name;
	private String symbol_pick;
	private String name;
	private Timestamp date_time;
	public ZilaPanchayat(int zila_id, String symbol_name, String symbol_pick, String name, Timestamp date_time) {
		super();
		this.zila_id = zila_id;
		this.symbol_name = symbol_name;
		this.symbol_pick = symbol_pick;
		this.name = name;
		this.date_time = date_time;
	}
	public ZilaPanchayat(String symbol_name, String symbol_pick, String name) {
		super();
		this.symbol_name = symbol_name;
		this.symbol_pick = symbol_pick;
		this.name = name;
	}
	public ZilaPanchayat() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getZila_id() {
		return zila_id;
	}
	public void setZila_id(int zila_id) {
		this.zila_id = zila_id;
	}
	public String getSymbol_name() {
		return symbol_name;
	}
	public void setSymbol_name(String symbol_name) {
		this.symbol_name = symbol_name;
	}
	public String getSymbol_pick() {
		return symbol_pick;
	}
	public void setSymbol_pick(String symbol_pick) {
		this.symbol_pick = symbol_pick;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Timestamp getDate_time() {
		return date_time;
	}
	public void setDate_time(Timestamp date_time) {
		this.date_time = date_time;
	}
	
}
